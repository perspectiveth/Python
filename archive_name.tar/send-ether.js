const fs = require("fs");
const ethers = require("ethers");

(async () => {
    // Get command-line arguments
    const recipient = process.argv[2];
    const amountEth = process.argv[3];
    const privKeyPath = process.argv[4];
    const gasPriceGwei = process.argv[5]; // Custom gas price in Gwei

    if (!recipient || !amountEth || !privKeyPath || !gasPriceGwei) {
        console.error("Usage: node myscript.js <send_where_to> <amount_eth> <privkey_path> <gas_price_gwei>");
        process.exit(1);
    }

    // Read the private key from the specified file
    const privateKey = fs.readFileSync(privKeyPath, "utf8").trim();

    // Connect to Ethereum RPC via a provider (Ankr RPC used as an example)
    const provider = new ethers.providers.JsonRpcProvider("https://rpc.ankr.com/eth");

    // Create a wallet instance from the private key
    const wallet = new ethers.Wallet(privateKey, provider);

    // Convert gas price from Gwei to Wei
    const gasPriceWei = ethers.utils.parseUnits(gasPriceGwei, "gwei");

    // Build the transaction
    const tx = {
        to: recipient,
        value: ethers.utils.parseEther(amountEth), // Convert amount from ETH to Wei
        gasLimit: 21000, // Standard gas limit for ETH transfer
        gasPrice: gasPriceWei, // Use custom gas price
    };

    try {
        // Send the transaction
        const txResponse = await wallet.sendTransaction(tx);
        console.log("Transaction sent! Hash:", txResponse.hash);

        // Wait for the transaction to be mined
        const receipt = await txResponse.wait();
        console.log("Transaction mined! Block Number:", receipt.blockNumber);
    } catch (error) {
        console.error("Error sending transaction:", error);
    }
})();