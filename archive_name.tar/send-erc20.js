

const fs = require("fs");
const ethers = require("ethers");

// Define a list of supported tokens with their contract addresses
const tokenContracts = {
    USDT: "0xdAC17F958D2ee523a2206206994597C13D831ec7", // Tether (USDT) Mainnet Contract
    DAI: "0x6B175474E89094C44Da98b954EedeAC495271d0F", // DAI Stablecoin
    USDC: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48", // USD Coin (USDC)
};

(async () => {
    // Get command-line arguments
    const recipient = process.argv[2];
    const amountToken = process.argv[3]; // Amount in token units (e.g., 50 USDT)
    const tokenName = process.argv[4]; // Token name (e.g., USDT)
    const privKeyPath = process.argv[5];
    const gasPriceGwei = process.argv[6]; // Custom gas price in Gwei
    const gweiKeyword = process.argv[7]; // Should always be "gwei"

    if (!recipient || !amountToken || !tokenName || !privKeyPath || !gasPriceGwei || gweiKeyword !== "gwei") {
        console.error("Usage: node myscript.js <send_where_to> <amount_token> <token_name> <privkey_path> <amount_gwei> gwei");
        console.error("Example: node myscript.js 0xRecipientAddress 50 USDT privkey.txt 10 gwei");
        process.exit(1);
    }

    // Check if the token is supported
    const tokenAddress = tokenContracts[tokenName.toUpperCase()];
    if (!tokenAddress) {
        console.error(`Error: Token "${tokenName}" is not supported.`);
        console.error("Supported tokens:", Object.keys(tokenContracts).join(", "));
        process.exit(1);
    }

    // Read the private key from the specified file
    const privateKey = fs.readFileSync(privKeyPath, "utf8").trim();

    // Connect to Ethereum RPC via a provider (Ankr RPC used as an example)
    const provider = new ethers.providers.JsonRpcProvider("https://rpc.ankr.com/eth");

    // Create a wallet instance from the private key
    const wallet = new ethers.Wallet(privateKey, provider);

    // Convert gas price from Gwei to Wei
    const gasPriceWei = ethers.utils.parseUnits(gasPriceGwei, "gwei");

    // Create a contract instance for the ERC-20 token
    const abi = [
        "function transfer(address to, uint256 amount) public returns (bool)",
    ];
    const tokenContract = new ethers.Contract(tokenAddress, abi, wallet);

    // Convert amount to smallest unit (e.g., 6 decimals for USDT)
    const decimals = tokenName.toUpperCase() === "USDT" || tokenName.toUpperCase() === "USDC" ? 6 : 18; // Adjust based on token
    const amountInSmallestUnit = ethers.utils.parseUnits(amountToken, decimals);

    try {
        // Send the transaction by calling `transfer` on the token contract
        const txResponse = await tokenContract.transfer(recipient, amountInSmallestUnit, { gasPrice: gasPriceWei });
        console.log(`Transaction sent! Hash: ${txResponse.hash}`);

        // Wait for the transaction to be mined
        const receipt = await txResponse.wait();
        console.log("Transaction mined! Block Number:", receipt.blockNumber);
        console.log(`Sent ${amountToken} ${tokenName} to ${recipient}`);
    } catch (error) {
        console.error("Error sending transaction:", error);
    }
})();




