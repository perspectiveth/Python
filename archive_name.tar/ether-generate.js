const fs = require("fs");
const ethers = require("ethers");

// Read mnemonic phrase from `mnem.txt`
const mnemonicPath = process.argv[2];

const mnemonic = fs.readFileSync(mnemonicPath, "utf8").trim();

// Read BIP-39 passphrase from `passp.txt`
const passphrasePath = process.argv[3];
const passphrase = fs.readFileSync(passphrasePath, "utf8").trim();



// Get the derivation path from the command-line argument
const derivPath = process.argv[4];

if (!derivPath) {
  console.error("Error: Please provide a derivation path as an argument.");
  console.error("Example: node code.js m/1/5/0/0/0");
  process.exit(1);
}

// Derive wallet with the provided derivation path and passphrase
const hdnodePass = ethers.utils.HDNode.fromMnemonic(mnemonic, passphrase);
const wallet = hdnodePass.derivePath(derivPath);

// Log the address and private key to the console
console.log(`Address for derivation path "${derivPath}" with passphrase:`, wallet.address);
//console.log(`Private key for derivation path "${derivPath}" with passphrase:`, wallet.privateKey);

// save to where
const saveGeneratedPrivateKeyToThisPath = process.argv[5];

fs.writeFileSync(saveGeneratedPrivateKeyToThisPath, wallet.privateKey);
console.log("Private key has been written to your txt file");
